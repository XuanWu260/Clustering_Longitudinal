## generate an R package for testing
#'#' @param b , random effect
#' @param numCluster , the number of clusters
#' @importFrom stats kmeans
#' @importFrom stats sd
#' @export

EM=function(b,numCluster=999){

  ##initial value pi,mu, and sigma, which are computed by k-means
  initial_value=kmeans(b,numCluster)$cluster

  pi=vector() ##probability of the subject belongs to cluster k
  mu=list()
  sigma2=list()
  numerator=data.frame()
  denominator=vector()
  cond.prob=data.frame()
  clustering=vector()

  ##initial value
  for  (k in 1:numCluster){
    pi[k]=length(which(initial_value==k))/length(initial_value)

    ## compute mean, and sigma square
    if (dim(b)[2]==1){
      mu[[k]]=mean(b[which(initial_value==k),])
      sigma2[[k]]=sd(b[which(initial_value==k),])
    }
    else{
      mu[[k]]=apply(b[which(initial_value==k),],2,mean)
      sigma2[[k]]=cov(b[which(initial_value==k),])
    }


    ##### Expatation #####

    for (n in 1:dim(b)[1]){

      # Pk*g(b)/sum(Pk*g(b)) where g(.)~multivariate normal distribution
      x_minus_mu=as.numeric(b[n,]-mu[[k]])
      cov=as.matrix(sigma2[[k]])
      numerator[n,k]=pi[k]*multinormal(x_minus_mu,dim(b)[2],cov)

    }
  }
  for (k in 1:numCluster){
    for (n in 1:dim(b)[1]){
      denominator=apply(numerator,1,sum)
      cond.prob[n,k]=numerator[n,k]/denominator[n]   ##P(k|n) in interation i

    }
  }

  ##loglikelihood
  loglikelihood=vector()

  log_value=log(denominator)
  loglikelihood[1]=sum(log_value)
  length_loglikelihood=1
  diff=1

  ##### Maximazation:  ######
  cat('log likelihood every iteration', '\n')
  while (diff>1e-2 ){  ##

    for  (k in 1:numCluster){
      pi[k]=mean(cond.prob[,k])
      mu[[k]]=apply(cond.prob[,k]*b,2,sum)/sum(cond.prob[,k]) #

      unlist_mu=as.numeric(unlist(mu[[k]]))
      mu_matrix=matrix(rep(unlist_mu,dim(b)[1]),nrow=dim(b)[1],byrow=T)
      updated.x_minus_mu=b-mu_matrix

      prob_x_mu=as.matrix(cond.prob[,k]*updated.x_minus_mu)
      sigma2[[k]]=t(prob_x_mu)%*%as.matrix(updated.x_minus_mu)/sum(cond.prob[,k])


      for (n in 1:dim(b)[1]){

        # Pk*g(b)/sum(Pk*g(b)) where g(.)~mutilvariate normal distribution
        x_minus_mu=as.numeric(b[n,]-mu[[k]])

        numerator[n,k]=pi[k]*multinormal(x_minus_mu,dim(b)[2],sigma2[[k]])

      }

    }
    for (k in 1:numCluster){
      for (n in 1:dim(b)[1]){
        denominator=apply(numerator,1,sum)
        cond.prob[n,k]=numerator[n,k]/denominator[n]   ##P(k|n) in interation i
      }
    }

    ## compute loglikelihood
    length_loglikelihood=1+length_loglikelihood

    log_value=log(denominator)
    loglikelihood[length_loglikelihood]=sum(log_value)
    diff=loglikelihood[length_loglikelihood]-loglikelihood[length_loglikelihood-1]

    ##print the loglikelihood out every iteration
    cat(length_loglikelihood-1,':',loglikelihood[length_loglikelihood-1], '\n')

  } ##while


  ##final clustering
  for (n in 1:dim(b)[1]){clustering[n]=which.max(cond.prob[n,])}

  ##AIC
  center=list()
  ss=vector()

  newdataframe=data.frame(b,clustering)
  for (i in 1:dim(b)[2]){   ##degreeploy+1=dim(b)[2]
    center[[i]]=tapply(newdataframe[,i],newdataframe$clustering,mean)
  }

  centers=matrix(unlist(center),byrow=F,nrow=numCluster)  ##numCluster,centers of each cluster

  m = ncol(centers)
  n = length(clustering)
  k = nrow(centers)

  AIC=-2*loglikelihood[length_loglikelihood]+2*m*k


  result=list(clustering=clustering,AIC=AIC,loglikelihood=loglikelihood)
  return(result)
}
