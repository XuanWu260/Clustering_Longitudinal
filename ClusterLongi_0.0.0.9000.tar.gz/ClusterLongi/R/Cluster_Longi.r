## generate an R package for testing


#' @name Cluster_Longi
#' @title Cluster_Longi
#' @param formula , formula for the model
#' @param subID , subject for the data
#' @param data , dataset for the model
#' @param degreeply , the largest degree for the model
#' @param typeCluster , the type of clustering
#' @param numCluster , the number of clusters, can be not given
#'
#' @importFrom stats model.frame model.matrix model.response kmeans hclust dist cutree
#' @importFrom lme4 lmer
#' @importFrom nlme ranef fixef
#' @export


library(Matrix)
library(lme4)

Cluster_Longi=function(formula,subID,data,degreepoly,typeCluster,numCluster=999){

  mf=model.frame(formula=formula,data=data) ##data frame of GH,time,ID

  x=model.matrix(attr(mf,'terms'),data=mf)
  x=as.matrix(x)
  t=x[,-1] ##delete the intercept column
  y=model.response(mf)

  ## model fitting
  if (degreepoly==0){   ##y=beta0+b0i, beta~fixed effect, b~random effects
    fit=lmer(y~(1|subID),data=mf)

    ##save random effects
    random_effects=ranef(fit)
    b0=as.vector(unlist(random_effects))
    b=data.frame(b0)
  }

  if (degreepoly==1){    ##y=(beta0+b0i)+(beta1+b1i)*t
    fit=lmer(y~t+(t|subID),data=mf)

    random_effects=ranef(fit)
    b_vector=as.vector(unlist(random_effects))
    b_matrix=matrix(b_vector,ncol=2)
    b0=b_matrix[,1]
    b1=b_matrix[,2]
    b=data.frame(b0,b1)
  }

  if (degreepoly==2){    ##y=(beta0+b0i)+(beta1+b1i)*t+(beta2+b2i)*t^2
    t_square=t^2
    fit=lmer(y~t+t_square+(t|subID)+(t_square|subID),data=mf)

    random_effects=ranef(fit)
    b_vector=as.vector(unlist(random_effects))
    b_matrix=matrix(b_vector,ncol=4)
    b0=b_matrix[,1]++b_matrix[,3]
    b1=b_matrix[,2]
    b2=b_matrix[,4]
    b=data.frame(b0,b1,b2)
  }

  if (degreepoly==3){    ##y=(beta0+b0i)+(beta1+b1i)*t+(beta2+b2i)*t^2+(beta3+b3i)*t^3
    t_square=t^2
    t_cube=t^3
    fit=lmer(y~t+t_square+t_cube+(t|subID)+(t_square|subID)+(t_cube|subID),data=mf)

    random_effects=ranef(fit)
    b_vector=as.vector(unlist(random_effects))
    b_matrix=matrix(b_vector,ncol=6)
    b0=b_matrix[,1]+b_matrix[,3]+b_matrix[,5]
    b1=b_matrix[,2]
    b2=b_matrix[,4]
    b3=b_matrix[,6]
    b=data.frame(b0,b1,b2,b3)
  }

  if (degreepoly>3){
    fit=NA
    print('Warning: degreepoly >3 is not accepted')
  }

  summary=summary(fit)

  ##save fixed effects
  fixed_effects=fixef(fit)
  beta=as.vector(fixed_effects)

  ##numCluster is given
  if (numCluster!=999){

    ###kmeans
    if(typeCluster=='kmeans'){
      cluster=kmeans(b,numCluster)
      clustering=cluster$cluster

      #compute SSE
      m = ncol(cluster$centers)
      n = length(cluster$cluster)
      k = nrow(cluster$centers)
      sse = cluster$tot.withinss

    }


    ##EM algorithm
    if(typeCluster=='EM'){
      EM_result=EM(b,numCluster)
      clustering=EM_result$clustering
      AIC=EM_result$AIC
    }

    num.clustering=vector()
    clust.index=vector()
    for(i in 1:numCluster){
      num.clustering[i]=length(which(clustering==i))
    }
    names(num.clustering)=1:length(num.clustering)
  }
  ##numCluster is not given
  if (numCluster==999){


    ##kmeans
    sse=vector()
    if(typeCluster=='kmeans' ){
      AIC=vector()
      for (i in 1:5){
        cluster=kmeans(b,i)
        clustering=NA
        m = ncol(cluster$centers)
        n = length(cluster$cluster)
        k = nrow(cluster$centers)
        sse[i] = cluster$tot.withinss
      }
      names(sse)=c('1 Cluster','2 Clusters','3 Clusters',
                   '4 Clusters','5 Clusters')
    }


    ##EM
    if(typeCluster=='EM' ){

      AIC=list()
      for (i in 1:5){
        cat(i,'Cluster(s):')
        AIC[[i]]=EM(b,i)$AIC


      }
      AIC=unlist(AIC)
      names(AIC)=c('1 Cluster','2 Clusters','3 Clusters',
                   '4 Clusters','5 Clusters')
      clustering=NA
    }
    num.clustering=NA
  }



  if (typeCluster=='EM'){
    result=list('Mixed Effect(s):beta'=beta,
                'Random Effect(s):b'=b,
                'clustering'=clustering,
                'Num. of Members Each Cluster'=num.clustering,
                'AIC'=AIC)
  }
  if (typeCluster=='kmeans'){
    result=list('Mixed Effect(s):beta'=beta,
                'Random Effect(s):b'=b,
                'clustering'=clustering,
                'Num. of Members Each Cluster'=num.clustering,
                'SSE'=sse)
  }



  return(result)
}

