## generate an R package for testing
#'#' @param x_mu ,observed value minus the mean in multivariate normal distribution
#' @param k ,the dimension of multivariate normal distribution
#' @param sigma ,sigma in multivariate normal distribution
#' @export

multinormal=function(x_mu,k,sigma2){
  value=((2*pi)^k*det(sigma2))^(-0.5)*
    exp(-0.5*t(x_mu)%*%solve(sigma2)%*%x_mu)
  return(value)
}
