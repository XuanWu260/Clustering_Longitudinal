## generate an R package for testing

#' @name cgplot
#' @title cgplot
#' @param formula ,the formula for the model
#' @param subID ,subject for the data
#' @param clustering ,clustering for each observed value
#' @param data ,dataset for the model
#'
#' @importFrom stats model.matrix model.response lm coef
#' @importFrom ggplot2 ggplot aes geom_line stat_smooth xlab ylab facet_wrap
#' @importFrom gridExtra tableGrob grid.arrange
#' @importFrom grDevices dev.new
#' @export

library(ggplot2)
library(ggpmisc)
library(gridExtra)

cgplot=function(formula,subID,clustering,data){

  mf=model.frame(formula=formula,data=data) ##data frame of GH,time,ID

  x=model.matrix(attr(mf,'terms'),data=mf)
  x=as.matrix(x)
  t=x[,-1] ##delete the intercept column
  y=model.response(mf)
  dataframe=data.frame(subID,t,y,clustering) ##!!!

  p=ggplot(dataframe,aes(x=t,y=y,group=subID))+
    geom_line(color = "grey")+
    stat_smooth(aes(group = 1),method='lm',formula=y~x,se=FALSE)+

    xlab(names(mf)[2])+ylab(names(mf)[1])+  ##label the names
    facet_wrap(~clustering)

  ######paste the equations
  numcluster=length(levels(factor(dataframe$clustering)))
  timepoint=as.numeric(levels(factor(dataframe$t)))
  nameCluster=levels(factor(dataframe$clustering))

  newclusters=list()
  Intercept=vector()
  Slope=vector()
  num.clust=vector()
  for (j in 1:numcluster){
    newclusters[[j]]=dataframe[which(dataframe$clustering==levels(factor(dataframe$clustering))[j]),]
    meany=tapply(newclusters[[j]]$y,newclusters[[j]]$t,mean)
    mod=lm(meany~timepoint)
    Intercept[j]=coef(mod)[1]
    Slope[j]=coef(mod)[2]
    num.clust[j]=length(which(clustering==j))/length(timepoint)
  }

  equations=data.frame(nameCluster,Intercept,Slope,num.clust)

  ##table of intercepts and slopes
  tbl <- tableGrob(equations, rows=NULL)
  dev.new()
  grid.arrange(p, tbl,as.table=TRUE,heights=c(3,1))

}
